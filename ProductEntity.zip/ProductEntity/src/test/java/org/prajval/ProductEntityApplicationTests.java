package org.prajval;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductEntityApplicationTests {

	@Test
	void contextLoads() {
	}

}
